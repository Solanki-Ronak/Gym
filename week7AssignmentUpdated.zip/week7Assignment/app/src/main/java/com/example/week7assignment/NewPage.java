package com.example.week7assignment;

public class NewPage {
}
